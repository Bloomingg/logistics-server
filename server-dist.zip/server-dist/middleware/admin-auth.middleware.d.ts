import { NestMiddleware } from '@nestjs/common';
export declare class AdminAuthMiddleware implements NestMiddleware {
    use(req: any, res: any, next: () => void): void;
}
