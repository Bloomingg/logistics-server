import * as mongoose from 'mongoose';
export declare const orderSchema: mongoose.Schema<mongoose.Document<any>, mongoose.Model<mongoose.Document<any>>>;
