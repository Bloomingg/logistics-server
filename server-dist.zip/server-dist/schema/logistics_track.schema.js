"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logisticsTrackSchema = void 0;
const mongoose = require("mongoose");
const mongoose_1 = require("mongoose");
exports.logisticsTrackSchema = new mongoose.Schema({
    frequencyId: {
        type: mongoose_1.Schema.Types.ObjectId,
        required: true
    },
    startTime: {
        type: String,
        required: true
    },
    endTime: {
        type: String,
        required: true
    },
    curPost: {
        type: String,
        required: true
    },
    add_time: {
        type: Number,
        default: new Date().getTime()
    },
    last_time: {
        type: Number,
        default: new Date().getTime()
    }
});
//# sourceMappingURL=logistics_track.schema.js.map