"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.frequencySchema = void 0;
const mongoose = require("mongoose");
exports.frequencySchema = new mongoose.Schema({
    startCity: {
        type: String,
        required: true
    },
    endCity: {
        type: String,
        required: true
    },
    transNo: {
        type: String,
        required: true
    },
    treTime: {
        type: Number,
        required: true
    },
    routeId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true
    },
    add_time: {
        type: Number,
        default: new Date().getTime()
    },
    last_time: {
        type: Number,
        default: new Date().getTime()
    }
});
//# sourceMappingURL=frequency.schema.js.map