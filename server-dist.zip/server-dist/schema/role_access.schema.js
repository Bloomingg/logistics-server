"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleAccessSchema = void 0;
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
exports.RoleAccessSchema = new mongoose.Schema({
    access_id: { type: Array, required: true },
    role_id: { type: Schema.Types.ObjectId, required: true }
});
//# sourceMappingURL=role_access.schema.js.map