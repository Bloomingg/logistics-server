import * as mongoose from 'mongoose';
export declare const logisticsTrackSchema: mongoose.Schema<mongoose.Document<any>, mongoose.Model<mongoose.Document<any>>>;
