"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccessSchema = void 0;
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
exports.AccessSchema = new mongoose.Schema({
    module_name: { type: String, required: true },
    type: { type: Number, required: true },
    sort: {
        type: Number,
        default: 100
    },
    description: { type: String },
    status: {
        type: Number,
        default: 1
    },
    add_time: {
        type: Number,
        default: new Date().getTime()
    }
});
//# sourceMappingURL=access.schema.js.map