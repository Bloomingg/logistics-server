"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.orderSchema = void 0;
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
exports.orderSchema = new mongoose.Schema({
    frequencyId: { type: Schema.Types.ObjectId, required: true },
    obtain_time: {
        type: String,
    },
    status: {
        type: Number,
        default: 0
    },
    send_time: {
        type: String,
    },
    add_time: {
        type: Number,
        default: new Date().getTime()
    },
    price: {
        type: Number,
    }
});
//# sourceMappingURL=order.schema.js.map