"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminSchema = void 0;
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
exports.adminSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        minlength: 3,
        maxlength: 20
    },
    password: {
        type: String,
        required: true,
        minlength: 6,
    },
    status: {
        type: Number,
        default: 1
    },
    role_id: {
        type: Schema.Types.ObjectId,
        required: true,
    },
    add_time: {
        type: Number,
        default: new Date().getTime()
    },
    last_time: {
        type: Number,
        default: new Date().getTime()
    },
    is_Supper: {
        type: Number,
        default: 0
    }
});
//# sourceMappingURL=admin.schema.js.map