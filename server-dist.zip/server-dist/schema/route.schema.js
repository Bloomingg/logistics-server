"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.routeSchema = void 0;
const mongoose = require("mongoose");
exports.routeSchema = new mongoose.Schema({
    startCity: {
        type: String,
        required: true
    },
    endCity: {
        type: String,
        required: true
    },
    passCity: {
        type: Array
    },
    add_time: {
        type: Number,
        default: new Date().getTime()
    },
    last_time: {
        type: Number,
        default: new Date().getTime()
    }
});
//# sourceMappingURL=route.schema.js.map