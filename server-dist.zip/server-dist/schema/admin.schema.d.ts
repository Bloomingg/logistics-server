import * as mongoose from 'mongoose';
export declare const adminSchema: mongoose.Schema<mongoose.Document<any>, mongoose.Model<mongoose.Document<any>>>;
