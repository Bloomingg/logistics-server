import * as mongoose from 'mongoose';
export declare const AccessSchema: mongoose.Schema<mongoose.Document<any>, mongoose.Model<mongoose.Document<any>>>;
