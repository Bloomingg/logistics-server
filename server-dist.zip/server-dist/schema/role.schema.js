"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleSchema = void 0;
const mongoose = require("mongoose");
const d = new Date();
exports.RoleSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String },
    status: { type: Number, default: 1 },
    add_time: {
        type: Number,
        default: d.getTime()
    }
});
//# sourceMappingURL=role.schema.js.map