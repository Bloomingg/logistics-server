import * as mongoose from 'mongoose';
export declare const frequencySchema: mongoose.Schema<mongoose.Document<any>, mongoose.Model<mongoose.Document<any>>>;
