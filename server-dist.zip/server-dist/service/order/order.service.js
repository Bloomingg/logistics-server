"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose = require("mongoose");
const order_1 = require("../../interface/order");
let OrderService = class OrderService {
    constructor(orderModel) {
        this.orderModel = orderModel;
    }
    async findOrder(json, page, size) {
        let { orderId } = json;
        let cur = (page - 1) * size;
        if (orderId && orderId != undefined) {
            const _id = mongoose.Types.ObjectId(orderId);
            console.log(typeof _id);
            return await this.orderModel.aggregate([
                {
                    $lookup: {
                        from: "frequency",
                        localField: "frequencyId",
                        foreignField: "_id",
                        as: "frequencyInfo"
                    }
                },
                {
                    $lookup: {
                        from: "track",
                        localField: "frequencyId",
                        foreignField: "frequencyId",
                        as: "track"
                    }
                },
                {
                    $match: { '_id': _id }
                },
                {
                    $limit: size
                },
                {
                    $skip: cur
                }
            ]);
        }
        else {
            return await this.orderModel.aggregate([
                {
                    $lookup: {
                        from: "frequency",
                        localField: "frequencyId",
                        foreignField: "_id",
                        as: "frequencyInfo"
                    }
                },
                {
                    $limit: size
                },
                {
                    $skip: cur
                }
            ]);
        }
    }
    async countOrder(json) {
        const { orderId } = json;
        let json2 = {};
        if (orderId != undefined) {
            json2['_id'] = orderId;
        }
        console.log(json2);
        return await this.orderModel.countDocuments(json2);
    }
    async addOrder(json) {
        let model = new this.orderModel(json);
        return await model.save();
    }
    async updateOrder(_id, json) {
        return await this.orderModel.findByIdAndUpdate(_id, json);
    }
    async deleteOrder(_id) {
        return await this.orderModel.findByIdAndRemove(_id);
    }
};
OrderService = __decorate([
    common_1.Injectable(),
    __param(0, mongoose_1.InjectModel('Order')),
    __metadata("design:paramtypes", [Object])
], OrderService);
exports.OrderService = OrderService;
//# sourceMappingURL=order.service.js.map