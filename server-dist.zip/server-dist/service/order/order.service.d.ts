import { Schema } from 'mongoose';
import { findOrder, newOrder } from 'src/interface/order';
export declare class OrderService {
    private readonly orderModel;
    constructor(orderModel: any);
    findOrder(json: findOrder, page: number, size: number): Promise<any>;
    countOrder(json: findOrder): Promise<any>;
    addOrder(json: newOrder): Promise<any>;
    updateOrder(_id: Schema.Types.ObjectId, json: newOrder): Promise<any>;
    deleteOrder(_id: Schema.Types.ObjectId): Promise<any>;
}
