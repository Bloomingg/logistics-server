"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const user_1 = require("../../interface/user");
let UserService = class UserService {
    constructor(userModel, roleModel, accessModel, RoleAccessModel) {
        this.userModel = userModel;
        this.roleModel = roleModel;
        this.accessModel = accessModel;
        this.RoleAccessModel = RoleAccessModel;
    }
    async findUsers(json, page, size = 10) {
        let cur = (page - 1) * size;
        return await this.userModel.find(json).skip(cur).limit(size);
    }
    async getUsersCount(json) {
        return await this.userModel.countDocuments(json);
    }
    async addUser(json) {
        let model = new this.userModel(json);
        return await model.save();
    }
    async updateStatus(id, json) {
        return await this.userModel.findByIdAndUpdate(id, json);
    }
    async deleteUser(_id) {
        return await this.userModel.findByIdAndDelete(_id);
    }
    async findRole(json, page, size = 10) {
        let cur = (page - 1) * size;
        return await this.roleModel.find(json).skip(cur).limit(size);
    }
    async getRolesCount(json) {
        return await this.roleModel.countDocuments(json);
    }
    async addRole(json) {
        let model = new this.roleModel(json);
        return await model.save();
    }
    async updateRole(id, json) {
        return await this.roleModel.findByIdAndUpdate(id, json);
    }
    async deleteRole(_id) {
        return await this.roleModel.findByIdAndDelete(_id);
    }
    async findAccess(json, filed = {}) {
        return await this.accessModel.find(json, filed);
    }
    async addAccess(json) {
        let model = new this.accessModel(json);
        return await model.save();
    }
    async updateAccess(id, json) {
        return await this.accessModel.findByIdAndUpdate(id, json);
    }
    async deleteAccess(_id) {
        return await this.accessModel.findByIdAndDelete(_id);
    }
    async findRoleAccess(json) {
        return await this.RoleAccessModel.find(json);
    }
    async addRoleAccess(json) {
        let model = new this.RoleAccessModel(json);
        return await model.save();
    }
    async updateRoleAccess(id, json) {
        return await this.RoleAccessModel.findByIdAndUpdate(id, json);
    }
};
UserService = __decorate([
    common_1.Injectable(),
    __param(0, mongoose_1.InjectModel('User')), __param(1, mongoose_1.InjectModel('Role')), __param(2, mongoose_1.InjectModel('Access')), __param(3, mongoose_1.InjectModel('RoleAccess')),
    __metadata("design:paramtypes", [Object, Object, Object, Object])
], UserService);
exports.UserService = UserService;
//# sourceMappingURL=user.service.js.map