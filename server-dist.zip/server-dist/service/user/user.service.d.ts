import { Schema } from 'mongoose';
import { newUser, findUser, findRole, newRole, newAccess, findAccess, newRoleAccess, findRoleAccess } from "src/interface/user";
export declare class UserService {
    private readonly userModel;
    private readonly roleModel;
    private readonly accessModel;
    private readonly RoleAccessModel;
    constructor(userModel: any, roleModel: any, accessModel: any, RoleAccessModel: any);
    findUsers(json: findUser, page: number, size?: number): Promise<any>;
    getUsersCount(json: findUser): Promise<any>;
    addUser(json: newUser): Promise<any>;
    updateStatus(id: Schema.Types.ObjectId, json: findUser): Promise<any>;
    deleteUser(_id: Schema.Types.ObjectId): Promise<any>;
    findRole(json: findRole, page: number, size?: number): Promise<any>;
    getRolesCount(json: findRole): Promise<any>;
    addRole(json: newRole): Promise<any>;
    updateRole(id: Schema.Types.ObjectId, json: newRole): Promise<any>;
    deleteRole(_id: Schema.Types.ObjectId): Promise<any>;
    findAccess(json: findAccess, filed?: {}): Promise<any>;
    addAccess(json: newAccess): Promise<any>;
    updateAccess(id: Schema.Types.ObjectId, json: newAccess): Promise<any>;
    deleteAccess(_id: Schema.Types.ObjectId): Promise<any>;
    findRoleAccess(json: findRoleAccess): Promise<any>;
    addRoleAccess(json: newRoleAccess): Promise<any>;
    updateRoleAccess(id: Schema.Types.ObjectId, json: newRoleAccess): Promise<any>;
}
