"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolsService = void 0;
const common_1 = require("@nestjs/common");
const svgCaptcha = require("svg-captcha");
const md5 = require("md5");
const jwt = require("jsonwebtoken");
const tools_1 = require("../../interface/tools");
let ToolsService = class ToolsService {
    captcha(size, fontSize, width, height, bac) {
        let captcha = svgCaptcha.create({
            size: size,
            fontSize: fontSize,
            width: width,
            height: height,
            background: bac
        });
        return captcha;
    }
    getMd5(str) {
        return md5(str);
    }
    getJwt(userInfo) {
        const token = jwt.sign({ username: userInfo.username, role_id: userInfo.role_id }, 'blooming', {
            expiresIn: 60 * 60 * 24
        });
        console.log(token);
        return token;
    }
    veriToken(token) {
        try {
            const decoded = jwt.verify(token, 'blooming');
            console.log(decoded);
            return decoded;
        }
        catch (error) {
            return false;
        }
    }
    sendResData(data) {
        let resData = {
            code: data.code || 200,
            suc: data.suc || true,
            msg: data.msg || "成功",
            data: data.data || null
        };
        return resData;
    }
};
ToolsService = __decorate([
    common_1.Injectable()
], ToolsService);
exports.ToolsService = ToolsService;
//# sourceMappingURL=tools.service.js.map