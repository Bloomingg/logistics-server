import * as svgCaptcha from 'svg-captcha';
import { resFormat } from "src/interface/tools";
export declare class ToolsService {
    captcha(size: number, fontSize: number, width: number, height: number, bac: string): svgCaptcha.CaptchaObj;
    getMd5(str: string): any;
    getJwt(userInfo: any): any;
    veriToken(token: string): any;
    sendResData(data: resFormat): {
        code: Number;
        suc: Boolean;
        msg: String;
        data: Object;
    };
}
