"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransportService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const transport_1 = require("../../interface/transport");
let TransportService = class TransportService {
    constructor(routeModel, frequencyModel, trackModel) {
        this.routeModel = routeModel;
        this.frequencyModel = frequencyModel;
        this.trackModel = trackModel;
    }
    async findRoute(json, page, size = 10) {
        console.log(json);
        let cur = (page - 1) * size;
        return await this.routeModel.find(json).skip(cur).limit(size);
    }
    async getRouteCount(json) {
        return await this.routeModel.countDocuments(json);
    }
    async addRoute(json) {
        let model = new this.routeModel(json);
        return await model.save();
    }
    async updateRoute(id, json) {
        return await this.routeModel.findByIdAndUpdate(id, json);
    }
    async deleteRoute(id) {
        return await this.routeModel.findByIdAndRemove(id);
    }
    async findFrequency(json, page, size = 10) {
        let cur = (page - 1) * size;
        return await this.frequencyModel.find(json).skip(cur).limit(size);
    }
    async getFrequencyCount(json) {
        return await this.frequencyModel.countDocuments(json);
    }
    async addFrequency(json) {
        let model = new this.frequencyModel(json);
        return await model.save();
    }
    async updateFrequency(id, json) {
        return await this.frequencyModel.findByIdAndUpdate(id, json);
    }
    async deleteFrequency(id) {
        return await this.frequencyModel.findByIdAndRemove(id);
    }
    async findTrack(json, page, size = 10) {
        let cur = (page - 1) * size;
        const { frequencyId } = json;
        if (frequencyId == undefined) {
            return await this.trackModel.aggregate([
                {
                    $lookup: {
                        from: "frequency",
                        localField: "frequencyId",
                        foreignField: "_id",
                        as: "frequencyInfo"
                    }
                },
                {
                    $limit: size
                },
                {
                    $skip: cur
                }
            ]);
        }
        else {
            return await this.trackModel.aggregate([
                {
                    $lookup: {
                        from: "frequency",
                        localField: "frequencyId",
                        foreignField: "_id",
                        as: "frequencyInfo"
                    }
                },
                {
                    $match: { "frequencyId": frequencyId }
                },
                {
                    $limit: size
                },
                {
                    $skip: cur
                }
            ]);
        }
    }
    async getTrackCount(json) {
        return await this.trackModel.countDocuments(json);
    }
    async addTrack(json) {
        console.log(json);
        let model = new this.trackModel(json);
        return await model.save();
    }
    async updateTrack(id, json) {
        return await this.trackModel.findByIdAndUpdate(id, json);
    }
    async deleteTrack(id) {
        return await this.trackModel.findByIdAndRemove(id);
    }
};
TransportService = __decorate([
    common_1.Injectable(),
    __param(0, mongoose_1.InjectModel('Route')), __param(1, mongoose_1.InjectModel('Frequency')), __param(2, mongoose_1.InjectModel('LogisticsTrack')),
    __metadata("design:paramtypes", [Object, Object, Object])
], TransportService);
exports.TransportService = TransportService;
//# sourceMappingURL=transport.service.js.map