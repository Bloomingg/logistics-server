import { Schema } from 'mongoose';
import { newRoute, findRoute, newFrequency, findFrequency, findTrack, newTrack } from "src/interface/transport";
export declare class TransportService {
    private readonly routeModel;
    private readonly frequencyModel;
    private readonly trackModel;
    constructor(routeModel: any, frequencyModel: any, trackModel: any);
    findRoute(json: findRoute, page: number, size?: number): Promise<any>;
    getRouteCount(json: findRoute): Promise<any>;
    addRoute(json: newRoute): Promise<any>;
    updateRoute(id: Schema.Types.ObjectId, json: newRoute): Promise<any>;
    deleteRoute(id: Schema.Types.ObjectId): Promise<any>;
    findFrequency(json: findFrequency, page: number, size?: number): Promise<any>;
    getFrequencyCount(json: findFrequency): Promise<any>;
    addFrequency(json: newFrequency): Promise<any>;
    updateFrequency(id: Schema.Types.ObjectId, json: newFrequency): Promise<any>;
    deleteFrequency(id: Schema.Types.ObjectId): Promise<any>;
    findTrack(json: findTrack, page: number, size?: number): Promise<any>;
    getTrackCount(json: findTrack): Promise<any>;
    addTrack(json: newTrack): Promise<any>;
    updateTrack(id: Schema.Types.ObjectId, json: newTrack): Promise<any>;
    deleteTrack(id: Schema.Types.ObjectId): Promise<any>;
}
