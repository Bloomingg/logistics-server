export interface resFormat {
    code?: Number;
    suc?: Boolean;
    msg?: String;
    data?: Object;
}
