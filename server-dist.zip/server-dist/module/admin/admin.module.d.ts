export declare class AdminModule {
}
