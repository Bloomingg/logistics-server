"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginController = void 0;
const common_1 = require("@nestjs/common");
const tools_service_1 = require("../../../service/tools/tools.service");
const user_service_1 = require("../../../service/user/user.service");
let LoginController = class LoginController {
    constructor(toolsService, userService) {
        this.toolsService = toolsService;
        this.userService = userService;
    }
    async doLogin(req, res) {
        const username = req.body.username;
        let password = req.body.password;
        const vericode = req.body.vericode;
        let resData = {
            code: 202,
            suc: false,
            msg: "",
            data: null
        };
        if (vericode == undefined) {
            resData.msg = "请输入验证码！";
            res.send(resData);
            return;
        }
        if (username == "" || password.length < 6) {
            resData.msg = "账号或密码格式错误！";
        }
        else {
            if (vericode.toUpperCase() == req.session.vericode.toUpperCase()) {
                password = this.toolsService.getMd5(password);
                const findResult = await this.userService.findUsers({ username: username }, 1);
                if (findResult.length > 0 && findResult[0].status == 1) {
                    if (findResult[0].password != password) {
                        resData.msg = "密码错误！";
                    }
                    else {
                        const { _id, role_id } = findResult[0];
                        const updateResult = await this.userService.updateStatus(_id, { last_time: new Date().getTime() });
                        const token = this.toolsService.getJwt({ username, role_id });
                        resData.code = 200;
                        resData.suc = true;
                        resData.msg = "登录成功！";
                        resData.data = {
                            username: username,
                            token: token,
                        };
                    }
                }
                else {
                    resData.msg = "账号不存在！";
                }
            }
            else {
                resData.msg = "验证码错误！";
            }
        }
        res.send(resData);
    }
    getVericode(req, res) {
        const svgCaptcha = this.toolsService.captcha(4, 50, 80, 40, "#cc9966");
        req.session.vericode = svgCaptcha.text;
        console.log(svgCaptcha.text);
        res.type('svg');
        res.send(svgCaptcha.data);
    }
    async getInfo(req, res) {
        const authorization = req.headers.authorization;
        const userInfo = this.toolsService.veriToken(authorization);
        const { role_id } = userInfo;
        let resData = {};
        try {
            const accessResult = await this.userService.findRoleAccess({ role_id: role_id });
            let role = await this.userService.findRole({ _id: role_id }, 1);
            role = role[0].title;
            let accessList = accessResult[0].access_id;
            let access = [];
            for (let i = 0; i < accessList.length; i++) {
                const tmp = await this.userService.findAccess({ _id: accessList[i] });
                console.log(accessList[i]);
                console.log(tmp);
                access.push(tmp[0]);
            }
            const avatar = 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif';
            resData = this.toolsService.sendResData({ msg: "获取成功", data: { accesses: access, avatar, role } });
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "获取失败：" + error, suc: false, code: 218 });
        }
        res.send(resData);
    }
};
__decorate([
    common_1.Post('doLogin'),
    __param(0, common_1.Req()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], LoginController.prototype, "doLogin", null);
__decorate([
    common_1.Get('getVericode'),
    __param(0, common_1.Req()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], LoginController.prototype, "getVericode", null);
__decorate([
    common_1.Get('getInfo'),
    __param(0, common_1.Req()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], LoginController.prototype, "getInfo", null);
LoginController = __decorate([
    common_1.Controller('login'),
    __metadata("design:paramtypes", [tools_service_1.ToolsService, user_service_1.UserService])
], LoginController);
exports.LoginController = LoginController;
//# sourceMappingURL=login.controller.js.map