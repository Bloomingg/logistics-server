import { ToolsService } from '../../../service/tools/tools.service';
import { UserService } from "src/service/user/user.service";
export declare class LoginController {
    private toolsService;
    private userService;
    constructor(toolsService: ToolsService, userService: UserService);
    doLogin(req: any, res: any): Promise<void>;
    getVericode(req: any, res: any): void;
    getInfo(req: any, res: any): Promise<void>;
}
