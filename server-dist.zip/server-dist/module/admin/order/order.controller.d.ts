import { OrderService } from 'src/service/order/order.service';
import { ToolsService } from 'src/service/tools/tools.service';
export declare class OrderController {
    private toolsService;
    private orderService;
    constructor(toolsService: ToolsService, orderService: OrderService);
    getOrder(query: any, res: any): Promise<void>;
    addOrder(body: any, res: any): Promise<void>;
    updateOrder(body: any, res: any): Promise<void>;
    deleteOrder(query: any, res: any): Promise<void>;
}
