"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderController = void 0;
const common_1 = require("@nestjs/common");
const order_service_1 = require("../../../service/order/order.service");
const tools_service_1 = require("../../../service/tools/tools.service");
let OrderController = class OrderController {
    constructor(toolsService, orderService) {
        this.toolsService = toolsService;
        this.orderService = orderService;
    }
    async getOrder(query, res) {
        let { orderId, page, size } = query;
        let reqData = {};
        let resData = {};
        if (page == undefined) {
            resData = this.toolsService.sendResData({ msg: "请输入分页信息", suc: false, code: 218 });
        }
        if (size == undefined)
            size = 10;
        if (orderId != "" && orderId != undefined)
            reqData['orderId'] = orderId;
        page = parseInt(page);
        size = parseInt(size);
        try {
            const result = await this.orderService.findOrder(reqData, page, size);
            console.log(result);
            const total = await this.orderService.countOrder(reqData);
            resData = this.toolsService.sendResData({ msg: "查询成功", data: { orderList: result, total, page } });
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "查询失败：" + error, suc: false, code: 218 });
        }
        res.send(resData);
    }
    async addOrder(body, res) {
        const { frequencyId, obtain_time, status, send_time, price } = body;
        let resData = {};
        let reqData = {
            frequencyId,
            obtain_time,
            status,
            send_time,
            price
        };
        try {
            const result = await this.orderService.addOrder(reqData);
            resData = this.toolsService.sendResData({ msg: "新增成功" });
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "新增失败：" + error, suc: false, code: 218 });
        }
        res.send(resData);
    }
    async updateOrder(body, res) {
        const { _id, frequencyId, obtain_time, status, send_time, price } = body;
        let resData = {};
        let reqData = {
            _id,
            frequencyId,
            obtain_time,
            status,
            send_time,
            price
        };
        try {
            const result = await this.orderService.updateOrder(_id, reqData);
            resData = this.toolsService.sendResData({ msg: "修改成功" });
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "修改失败：" + error, suc: false, code: 218 });
        }
        res.send(resData);
    }
    async deleteOrder(query, res) {
        const { _id } = query;
        let resData = {};
        try {
            const result = await this.orderService.deleteOrder(_id);
            console.log(result);
            resData = this.toolsService.sendResData({ msg: "删除成功" });
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "删除失败：" + error, suc: false, code: 218 });
        }
        res.send(resData);
    }
};
__decorate([
    common_1.Get('getOrder'),
    __param(0, common_1.Query()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "getOrder", null);
__decorate([
    common_1.Post('addOrder'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "addOrder", null);
__decorate([
    common_1.Post('updateOrder'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "updateOrder", null);
__decorate([
    common_1.Get('deleteOrder'),
    __param(0, common_1.Query()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "deleteOrder", null);
OrderController = __decorate([
    common_1.Controller('order'),
    __metadata("design:paramtypes", [tools_service_1.ToolsService, order_service_1.OrderService])
], OrderController);
exports.OrderController = OrderController;
//# sourceMappingURL=order.controller.js.map