"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminModule = void 0;
const common_1 = require("@nestjs/common");
const login_controller_1 = require("./login/login.controller");
const transport_controller_1 = require("./transport/transport.controller");
const finance_controller_1 = require("./finance/finance.controller");
const order_controller_1 = require("./order/order.controller");
const user_controller_1 = require("./user/user.controller");
const tools_service_1 = require("../../service/tools/tools.service");
const mongoose_1 = require("@nestjs/mongoose");
const user_service_1 = require("../../service/user/user.service");
const transport_service_1 = require("../../service/transport/transport.service");
const admin_schema_1 = require("../../schema/admin.schema");
const access_schema_1 = require("../../schema/access.schema");
const role_schema_1 = require("../../schema/role.schema");
const role_access_schema_1 = require("../../schema/role_access.schema");
const route_schema_1 = require("../../schema/route.schema");
const frequency_schema_1 = require("../../schema/frequency.schema");
const logistics_track_schema_1 = require("../../schema/logistics_track.schema");
const order_schema_1 = require("../../schema/order.schema");
const order_service_1 = require("../../service/order/order.service");
let AdminModule = class AdminModule {
};
AdminModule = __decorate([
    common_1.Module({
        imports: [mongoose_1.MongooseModule.forFeature([
                { name: 'User', schema: admin_schema_1.adminSchema, collection: "user" },
                { name: 'Role', schema: role_schema_1.RoleSchema, collection: "role" },
                { name: 'Access', schema: access_schema_1.AccessSchema, collection: "access" },
                { name: 'RoleAccess', schema: role_access_schema_1.RoleAccessSchema, collection: "role_access" },
                { name: 'Route', schema: route_schema_1.routeSchema, collection: "route" },
                { name: 'Frequency', schema: frequency_schema_1.frequencySchema, collection: "frequency" },
                { name: 'LogisticsTrack', schema: logistics_track_schema_1.logisticsTrackSchema, collection: "track" },
                { name: 'Order', schema: order_schema_1.orderSchema, collection: "order" },
            ])
        ],
        controllers: [login_controller_1.LoginController, transport_controller_1.TransportController, finance_controller_1.FinanceController, order_controller_1.OrderController, user_controller_1.UserController],
        providers: [tools_service_1.ToolsService, user_service_1.UserService, transport_service_1.TransportService, order_service_1.OrderService]
    })
], AdminModule);
exports.AdminModule = AdminModule;
//# sourceMappingURL=admin.module.js.map