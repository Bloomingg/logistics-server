"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransportController = void 0;
const common_1 = require("@nestjs/common");
const tools_service_1 = require("../../../service/tools/tools.service");
const transport_service_1 = require("../../../service/transport/transport.service");
let TransportController = class TransportController {
    constructor(transportService, toolsService) {
        this.transportService = transportService;
        this.toolsService = toolsService;
    }
    async getAllRoute(body, res) {
        const { page, size, startCity, endCity } = body;
        let reqData = {};
        if (startCity != "" && startCity != undefined)
            reqData['startCity'] = startCity;
        if (endCity != "" && endCity != undefined)
            reqData['endCity'] = endCity;
        try {
            const data = await this.transportService.findRoute(reqData, page, size);
            const total = await this.transportService.getRouteCount(reqData);
            const resData = this.toolsService.sendResData({ msg: "查询成功", data: { routeList: data, total: total, page: page } });
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "查询失败:" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async addRoute(body, res) {
        const { startCity, endCity, passCity } = body;
        const reqData = {
            startCity,
            endCity,
            passCity
        };
        try {
            let resData = {};
            const result = await this.transportService.addRoute(reqData);
            if (result.startCity == startCity) {
                resData = this.toolsService.sendResData({ msg: "新增成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "新增失败", code: 218, suc: false });
            }
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "新增失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async updateRoute(body, res) {
        const { _id, startCity, endCity, passCity } = body;
        const reqData = {
            last_time: new Date().getTime(),
            _id,
            startCity,
            endCity,
            passCity
        };
        try {
            let resData = {};
            const result = await this.transportService.updateRoute(_id, reqData);
            console.log(result);
            if (_id == result.id) {
                resData = this.toolsService.sendResData({ msg: "修改成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "修改失败", code: 218, suc: false });
            }
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "修改失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async deleteRoute(body, res) {
        const { _id } = body;
        try {
            let resData = {};
            const result = await this.transportService.deleteRoute(_id);
            console.log(result);
            if (_id == result.id) {
                resData = this.toolsService.sendResData({ msg: "删除成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "删除失败", code: 218, suc: false });
            }
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "删除失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async getAllFrequency(body, res) {
        const { page, size, startCity, endCity, transNo } = body;
        let reqData = {};
        if (startCity != "" && startCity != undefined)
            reqData['startCity'] = startCity;
        if (endCity != "" && endCity != undefined)
            reqData['endCity'] = endCity;
        if (transNo != "" && transNo != undefined)
            reqData['transNo'] = transNo;
        try {
            const data = await this.transportService.findFrequency(reqData, page, size);
            const total = await this.transportService.getFrequencyCount(reqData);
            const resData = this.toolsService.sendResData({ msg: "查询成功", data: { freqList: data, total: total, page: page } });
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "查询失败:" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async addFrequency(body, res) {
        const { startCity, endCity, transNo, treTime, routeId } = body;
        const reqData = {
            startCity,
            endCity,
            transNo,
            treTime,
            routeId
        };
        try {
            let resData = {};
            const result = await this.transportService.addFrequency(reqData);
            if (result.startCity == startCity) {
                resData = this.toolsService.sendResData({ msg: "新增成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "新增失败", code: 218, suc: false });
            }
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "新增失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async updateFrequency(body, res) {
        const { _id, startCity, endCity, transNo, treTime, routeId } = body;
        const reqData = {
            last_time: new Date().getTime(),
            _id,
            startCity,
            endCity,
            transNo,
            treTime,
            routeId
        };
        try {
            let resData = {};
            const result = await this.transportService.updateFrequency(_id, reqData);
            console.log(result);
            if (_id == result.id) {
                resData = this.toolsService.sendResData({ msg: "修改成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "修改失败", code: 218, suc: false });
            }
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "修改失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async deleteFrequency(body, res) {
        const { _id } = body;
        try {
            let resData = {};
            const result = await this.transportService.deleteFrequency(_id);
            console.log(result);
            if (_id == result.id) {
                resData = this.toolsService.sendResData({ msg: "删除成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "删除失败", code: 218, suc: false });
            }
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "删除失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async getAllTrack(body, res) {
        const { page, size, startCity, endCity, transNo } = body;
        let reqData = {};
        let resData = {};
        if (startCity != "" && startCity != undefined)
            reqData['startCity'] = startCity;
        if (endCity != "" && endCity != undefined)
            reqData['endCity'] = endCity;
        if (transNo != "" && transNo != undefined)
            reqData['transNo'] = transNo;
        try {
            let data = [];
            let frequencyIds = [];
            let total = 0;
            const Frequency = await this.transportService.findFrequency(reqData, 1, 999);
            console.log('Frequency--------------');
            console.log(Frequency);
            if (Frequency.length == 0) {
                data = [];
            }
            else {
                for (let i = 0; i < Frequency.length; i++) {
                    const id = Frequency[i]._id;
                    frequencyIds.push(id);
                }
                console.log('frequencyIds--------------');
                console.log(frequencyIds);
                if (JSON.stringify(reqData) == '{}') {
                    data = await this.transportService.findTrack({}, page, size);
                    total += await this.transportService.getTrackCount({});
                }
                else {
                    for (let i = 0; i < frequencyIds.length; i++) {
                        const tmpData = await this.transportService.findTrack({ frequencyId: frequencyIds[i] }, page, size);
                        console.log(tmpData);
                        total += await this.transportService.getTrackCount({ frequencyId: frequencyIds[i] });
                        data = [...data, ...tmpData];
                    }
                }
            }
            resData = this.toolsService.sendResData({ msg: "查询成功", data: { trackList: data, total: total, page: page } });
            res.send(resData);
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "查询失败:" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async addTrack(body, res) {
        const { startTime, endTime, curPost, frequencyId } = body;
        try {
            let resData = {};
            const reqData = {
                startTime,
                endTime,
                frequencyId,
                curPost
            };
            try {
                const result = await this.transportService.addTrack(reqData);
                resData = this.toolsService.sendResData({ msg: "新增成功" });
            }
            catch (error) {
                resData = this.toolsService.sendResData({ msg: "新增失败：" + error, code: 218, suc: false });
                res.send(resData);
            }
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "新增失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async updateTrack(body, res) {
        const { _id, frequencyId, startTime, endTime, curPost } = body;
        try {
            let resData = {};
            const reqData = {
                last_time: new Date().getTime(),
                _id,
                frequencyId,
                startTime,
                endTime,
                curPost
            };
            try {
                const result = await this.transportService.updateTrack(_id, reqData);
                console.log(result);
                resData = this.toolsService.sendResData({ msg: "修改成功" });
            }
            catch (error) {
                resData = this.toolsService.sendResData({ msg: "修改失败：" + error, code: 218, suc: false });
                res.send(resData);
            }
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "修改失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async deleteTrack(body, res) {
        const { _id } = body;
        try {
            let resData = {};
            const result = await this.transportService.deleteTrack(_id);
            console.log(result);
            if (_id == result.id) {
                resData = this.toolsService.sendResData({ msg: "删除成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "删除失败", code: 218, suc: false });
            }
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "删除失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
};
__decorate([
    common_1.Post('route/getAll'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TransportController.prototype, "getAllRoute", null);
__decorate([
    common_1.Post('route/addRoute'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TransportController.prototype, "addRoute", null);
__decorate([
    common_1.Post('route/updateRoute'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TransportController.prototype, "updateRoute", null);
__decorate([
    common_1.Post('route/deleteRoute'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TransportController.prototype, "deleteRoute", null);
__decorate([
    common_1.Post('frequency/getAll'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TransportController.prototype, "getAllFrequency", null);
__decorate([
    common_1.Post('frequency/addFrequency'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TransportController.prototype, "addFrequency", null);
__decorate([
    common_1.Post('frequency/updateFrequency'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TransportController.prototype, "updateFrequency", null);
__decorate([
    common_1.Post('frequency/deleteFrequency'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TransportController.prototype, "deleteFrequency", null);
__decorate([
    common_1.Post('track/getAll'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TransportController.prototype, "getAllTrack", null);
__decorate([
    common_1.Post('track/addTrack'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TransportController.prototype, "addTrack", null);
__decorate([
    common_1.Post('track/updateTrack'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TransportController.prototype, "updateTrack", null);
__decorate([
    common_1.Post('track/deleteTrack'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TransportController.prototype, "deleteTrack", null);
TransportController = __decorate([
    common_1.Controller('transport'),
    __metadata("design:paramtypes", [transport_service_1.TransportService, tools_service_1.ToolsService])
], TransportController);
exports.TransportController = TransportController;
//# sourceMappingURL=transport.controller.js.map