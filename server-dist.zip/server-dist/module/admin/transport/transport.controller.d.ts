import { ToolsService } from 'src/service/tools/tools.service';
import { TransportService } from 'src/service/transport/transport.service';
export declare class TransportController {
    private transportService;
    private toolsService;
    constructor(transportService: TransportService, toolsService: ToolsService);
    getAllRoute(body: any, res: any): Promise<void>;
    addRoute(body: any, res: any): Promise<void>;
    updateRoute(body: any, res: any): Promise<void>;
    deleteRoute(body: any, res: any): Promise<void>;
    getAllFrequency(body: any, res: any): Promise<void>;
    addFrequency(body: any, res: any): Promise<void>;
    updateFrequency(body: any, res: any): Promise<void>;
    deleteFrequency(body: any, res: any): Promise<void>;
    getAllTrack(body: any, res: any): Promise<void>;
    addTrack(body: any, res: any): Promise<void>;
    updateTrack(body: any, res: any): Promise<void>;
    deleteTrack(body: any, res: any): Promise<void>;
}
