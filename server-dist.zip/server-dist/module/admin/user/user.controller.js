"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const common_1 = require("@nestjs/common");
const user_1 = require("../../../interface/user");
const tools_service_1 = require("../../../service/tools/tools.service");
const user_service_1 = require("../../../service/user/user.service");
let UserController = class UserController {
    constructor(toolsService, userService) {
        this.toolsService = toolsService;
        this.userService = userService;
    }
    async getUserList(query, res) {
        let { page, size, username, status } = query;
        if (page == "" || page == undefined) {
            const resData = this.toolsService.sendResData({ msg: "请输入分页信息", suc: false, code: 218 });
            res.send(resData);
            return;
        }
        page = parseInt(page);
        size = parseInt(size);
        let reqData = {};
        let setSize = 10;
        if (username != "" && username != undefined)
            reqData['username'] = username;
        if (status != "" && status != undefined)
            reqData['status'] = status;
        if (size != "" && size != undefined)
            setSize = size;
        try {
            const data = await this.userService.findUsers(reqData, page, setSize);
            const total = await this.userService.getUsersCount(reqData);
            const resData = this.toolsService.sendResData({ msg: "查询成功", data: { userList: data, total: total, page: page } });
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "查询失败:" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async addUser(body, res) {
        const { username, password, status, role_id, is_Supper } = body;
        const md5Password = this.toolsService.getMd5(password);
        let resData = {};
        let reqData = {
            username,
            status,
            role_id,
            password: md5Password,
        };
        if (is_Supper != undefined)
            reqData['is_Supper'] = is_Supper;
        try {
            const result = await this.userService.addUser(reqData);
            console.log(result);
            resData = this.toolsService.sendResData({ msg: "新增成功" });
            res.send(resData);
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "新增失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async updateStatus(body, res) {
        try {
            let resData = {};
            const result = await this.userService.updateStatus(body._id, body);
            if (result._id == body._id) {
                resData = this.toolsService.sendResData({ msg: "操作成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "操作失败", suc: false, code: 218 });
            }
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "操作失败：" + error, suc: false, code: 218 });
            res.send(resData);
        }
    }
    async deleteUser(query, res) {
        const { _id } = query;
        let resData = {};
        if (_id == "" || _id == undefined) {
            resData = this.toolsService.sendResData({ msg: "删除失败，请传入正确的id", suc: false, code: 218 });
            res.send(resData);
            return false;
        }
        try {
            console.log(_id);
            const result = await this.userService.deleteUser(_id);
            if (result) {
                resData = this.toolsService.sendResData({ msg: "删除成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "删除失败，请传入正确的id", suc: false, code: 218 });
            }
            res.send(resData);
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "删除失败：" + error, suc: false, code: 218 });
            res.send(resData);
        }
    }
    async addRole(body, res) {
        const { title, description } = body;
        const reqData = {
            title,
            description
        };
        let resData = {};
        try {
            const result = await this.userService.addRole(reqData);
            console.log(result);
            if (result.title == title) {
                resData = this.toolsService.sendResData({ msg: "新增成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "新增失败", code: 218, suc: false });
            }
            res.send(resData);
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "新增失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async getRoles(query, res) {
        let { page, size } = query;
        let resData = {};
        if (page == "" || page == undefined) {
            resData = this.toolsService.sendResData({ msg: "请输入分页信息", suc: false, code: 218 });
            res.send(resData);
            return;
        }
        page = parseInt(page);
        size = parseInt(size);
        let reqData = {};
        let setSize = 10;
        if (size != "" && size != undefined)
            setSize = size;
        try {
            const data = await this.userService.findRole(reqData, page, setSize);
            const total = await this.userService.getRolesCount(reqData);
            resData = this.toolsService.sendResData({ msg: "查询成功", data: { roleList: data, total: total, page: page } });
            res.send(resData);
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "查询失败:" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async deleteRole(query, res) {
        const { _id } = query;
        let resData = {};
        if (_id == "" || _id == undefined) {
            resData = this.toolsService.sendResData({ msg: "删除失败，请传入正确的id", suc: false, code: 218 });
            res.send(resData);
            return false;
        }
        try {
            console.log(_id);
            const result = await this.userService.deleteRole(_id);
            if (result) {
                resData = this.toolsService.sendResData({ msg: "删除成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "删除失败，请传入正确的id", suc: false, code: 218 });
            }
            res.send(resData);
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "删除失败：" + error, suc: false, code: 218 });
            res.send(resData);
        }
    }
    async addAccess(body, res) {
        const { module_name, description, type, sort } = body;
        const reqData = {
            module_name,
            type,
            description,
            sort
        };
        let resData = {};
        try {
            const result = await this.userService.addAccess(reqData);
            console.log(result);
            if (result.module_name == module_name) {
                resData = this.toolsService.sendResData({ msg: "新增成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "新增失败", code: 218, suc: false });
            }
            res.send(resData);
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "新增失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async getAccesss(query, res) {
        let { module_name, type } = query;
        let resData = {};
        let reqData = {};
        if (module_name != "" && module_name != undefined)
            reqData['module_name'] = module_name;
        if (type != "" && type != undefined)
            reqData['type'] = type;
        try {
            const data = await this.userService.findAccess(reqData);
            resData = this.toolsService.sendResData({ msg: "查询成功", data: { accessList: data } });
            res.send(resData);
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "查询失败:" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async deleteAccesss(query, res) {
        const { _id } = query;
        let resData = {};
        if (_id == "" || _id == undefined) {
            resData = this.toolsService.sendResData({ msg: "删除失败，请传入正确的id", suc: false, code: 218 });
            res.send(resData);
            return false;
        }
        try {
            const result = await this.userService.deleteAccess(_id);
            if (result) {
                resData = this.toolsService.sendResData({ msg: "删除成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "删除失败，请传入正确的id", suc: false, code: 218 });
            }
            res.send(resData);
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "删除失败：" + error, suc: false, code: 218 });
            res.send(resData);
        }
    }
    async addRoleAccess(body, res) {
        const { role_id, access_id } = body;
        const reqData = {
            access_id,
            role_id,
        };
        console.log(access_id);
        let resData = {};
        try {
            const result = await this.userService.addRoleAccess(reqData);
            console.log(result);
            if (result.role_id == role_id) {
                resData = this.toolsService.sendResData({ msg: "新增成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "新增失败", code: 218, suc: false });
            }
            res.send(resData);
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "新增失败：" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
    async updateRoleAccess(body, res) {
        try {
            let resData = {};
            const result = await this.userService.updateRoleAccess(body._id, body);
            if (result._id == body._id) {
                resData = this.toolsService.sendResData({ msg: "操作成功" });
            }
            else {
                resData = this.toolsService.sendResData({ msg: "操作失败", suc: false, code: 218 });
            }
            res.send(resData);
        }
        catch (error) {
            const resData = this.toolsService.sendResData({ msg: "操作失败：" + error, suc: false, code: 218 });
            res.send(resData);
        }
    }
    async getRoleAccess(query, res) {
        let { access_id, role_id, _id } = query;
        let resData = {};
        let reqData = {
            role_id
        };
        if (access_id != "" && access_id != undefined)
            reqData['access_id'] = access_id;
        if (_id != "" && _id != undefined)
            reqData['_id'] = _id;
        try {
            const data = await this.userService.findRoleAccess(reqData);
            resData = this.toolsService.sendResData({ msg: "查询成功", data: { RoleAccessList: data } });
            res.send(resData);
        }
        catch (error) {
            resData = this.toolsService.sendResData({ msg: "查询失败:" + error, code: 218, suc: false });
            res.send(resData);
        }
    }
};
__decorate([
    common_1.Get('userList'),
    __param(0, common_1.Query()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "getUserList", null);
__decorate([
    common_1.Post('addUser'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "addUser", null);
__decorate([
    common_1.Post('updateStatus'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "updateStatus", null);
__decorate([
    common_1.Get('deleteUser'),
    __param(0, common_1.Query()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "deleteUser", null);
__decorate([
    common_1.Post('addRole'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "addRole", null);
__decorate([
    common_1.Get('getRoles'),
    __param(0, common_1.Query()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "getRoles", null);
__decorate([
    common_1.Get('deleteRole'),
    __param(0, common_1.Query()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "deleteRole", null);
__decorate([
    common_1.Post('addAccess'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "addAccess", null);
__decorate([
    common_1.Get('getAccess'),
    __param(0, common_1.Query()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "getAccesss", null);
__decorate([
    common_1.Get('deleteAccess'),
    __param(0, common_1.Query()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "deleteAccesss", null);
__decorate([
    common_1.Post('addRoleAccess'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "addRoleAccess", null);
__decorate([
    common_1.Post('updateRoleAccess'),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "updateRoleAccess", null);
__decorate([
    common_1.Get('getRoleAccess'),
    __param(0, common_1.Query()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "getRoleAccess", null);
UserController = __decorate([
    common_1.Controller('user'),
    __metadata("design:paramtypes", [tools_service_1.ToolsService, user_service_1.UserService])
], UserController);
exports.UserController = UserController;
//# sourceMappingURL=user.controller.js.map