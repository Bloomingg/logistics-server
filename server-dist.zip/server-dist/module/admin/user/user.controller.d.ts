import { ToolsService } from 'src/service/tools/tools.service';
import { UserService } from 'src/service/user/user.service';
export declare class UserController {
    private toolsService;
    private userService;
    constructor(toolsService: ToolsService, userService: UserService);
    getUserList(query: any, res: any): Promise<void>;
    addUser(body: any, res: any): Promise<void>;
    updateStatus(body: any, res: any): Promise<void>;
    deleteUser(query: any, res: any): Promise<boolean>;
    addRole(body: any, res: any): Promise<void>;
    getRoles(query: any, res: any): Promise<void>;
    deleteRole(query: any, res: any): Promise<boolean>;
    addAccess(body: any, res: any): Promise<void>;
    getAccesss(query: any, res: any): Promise<void>;
    deleteAccesss(query: any, res: any): Promise<boolean>;
    addRoleAccess(body: any, res: any): Promise<void>;
    updateRoleAccess(body: any, res: any): Promise<void>;
    getRoleAccess(query: any, res: any): Promise<void>;
}
